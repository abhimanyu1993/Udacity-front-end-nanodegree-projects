/*
This is empty on purpose! Your code to build the resume will go here.
 */
var bio = {
    "name": "Abhimanyu Tyagi",
    "role": "Web Developer",
    "contacts": {
        "email": "atyagi@buffalo.edu",
        "github": "abhimanyu1993",
        "twitter": "@schmaltzynator",
        "location": "Buffalo, New York, USA"
    },
    "biopic": "images/propic.jpg",
    "welcomeMessage": "I'm currently working as a Web Developer in Buffalo, New York.  Thanks for stopping by!",
    "skills": ["Front end web development", "JavaScript", "HTML5", "CSS3", "AJAX", "JQuery", "JSON", "multitasking", "critical thinking"]
};

var work = {
    "jobs": [{
            "employer": "University at Buffaloo",
            "title": "Student Assistant Web Developer",
            "location": "Buffalo, New York",
            "dates": "August 2016 - Current",
            "description": "Worked closely with a team of web designers and Photoshop experts to develop websites for the university professors and their respective classes."
        },
        {
            "employer": "Versatile Knowledge Consultants",
            "title": "Salesforce CRM intern",
            "location": "Jaipur, Rajasthan, India",
            "dates": "November 2015 - February 2016",
            "description": "Worked closely with a team on a module of a projecct, Bria4. Developed Visualforce pages, web socket and open CTI"
        },
        {
            "employer": "Gucci",
            "title": "Relationship management client intern",
            "location": "Gurgaon, India",
            "dates": "june 2013 - August 2013",
            "description": "handled client Relationship management with Gucci's top 5% clients. Worked closely with a supervisor as part of events management, duties included but were not limited to calling VIC clients and keeping up with them"
        }
    ]
};

var education = {
    "schools": [{
        "name": "University at Buffalo",
        "dates": "2012-2017",
        "location": "Buffalo, New York",
        "majors": ["Communication"],
        "url": "www.buffalo.edu"
    }],
    "onlineCourses": [{
            "name": "Udacity",
            "title": "Object-Oriented Javascript",
            "dates": "Decembefr 2016",
            "url": "https://www.udacity.com/course/ud015"
        },
        {
            "name": "Udacity",
            "title": "HTML5 Canvas",
            "dates": "December 2016 2016",
            "url": "https://www.udacity.com/course/ud292"
        },
        {
            "name": "Udacity",
            "title": "Javascript Basics",
            "dates": "December 2016",
            "url": "https://www.udacity.com/course/ud804"
        },
        {
            "name": "Udacity",
            "title": "Intro to HTML and CSS",
            "dates": "December 2014",
            "url": "https://www.udacity.com/course/ud304"
        },
        {
            "name": "Udacity",
            "title": "Web Development",
            "dates": "December 2016",
            "url": "https://www.udacity.com/course/cs253"
        }
    ]
};

var projects = {
    "projects": [{
            "title": "Roc Summer Explosion",
            "dates": "June 2016 - August 2016",
            "description": "Developed website for a rap concert in Rochester, New York feature popular hip hop artists like DMX, Ja Rule and Young Thug. ",
            "images": ["images/rocsummer.png"],
            "url": "http://www.rocsummerexplosion.com"
        },
        {
            "title": "Founder-Campus Cruize",
            "dates": "June 2016",
            "description": "CampusCruize was an early-stage Tech Startup that connects college Drivers and Riders to local city events. My work there included creating an iPhone and Android app for the business as well as develop a website with a team of designers and Photoshop experts",
            "images": ["images/campus.png"],
            "url": "http://www.campuscruize.org/"
        },
        {
            "title": "New Era Hackathon Mobile App",
            "dates": "November 2016",
            "description": "Secured second position overall by developing prototype for New Era Caps mobile app using photoshop images and InVision to create clickable functions.",
            "images": ["images/newera.png"]
        }
    ]
};

bio.display = function() {
    var formattedName = HTMLheaderName.replace("%data%", bio.name);
    var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
    var formattedBioPic = HTMLbioPic.replace("%data%", bio.biopic);
    var formattedWelcomeMsg = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);

    var formattedContactInfo = [];
    formattedContactInfo.push(HTMLemail.replace("%data%", bio.contacts.email));
    formattedContactInfo.push(HTMLgithub.replace("%data%", bio.contacts.github));
    formattedContactInfo.push(HTMLtwitter.replace("%data%", bio.contacts.twitter));
    formattedContactInfo.push(HTMLlocation.replace("%data%", bio.contacts.location));


    $("#header").prepend(formattedRole);
    $("#header").prepend(formattedName);
    $("#header").append(formattedBioPic);
    $("#header").append(formattedWelcomeMsg);

    if (bio.skills.length > 0) {
        $("#header").append(HTMLskillsStart);

        bio.skills.forEach(function(skill) {
            $('#skills').append(HTMLskills.replace('%data%', skill));
        });
    }

    for (var i = 0; i < formattedContactInfo.length; i++) {
        $("#topContacts").append(formattedContactInfo[i]);
        $("#footerContacts").append(formattedContactInfo[i]);
    }
};

bio.display();

work.display = function() {

    if (work.jobs.length > 0) {

        $("#workExperience").append(HTMLworkStart);

        for (var k = 0; k < work.jobs.length; k++) {
            var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[k].employer);
            var formattedWorkTitle = HTMLworkTitle.replace("%data%", work.jobs[k].title);
            var formattedWorkLocation = HTMLworkLocation.replace("%data%", work.jobs[k].location);
            var formattedDates = HTMLworkDates.replace("%data%", work.jobs[k].dates);
            var formattedWorkDescription = HTMLworkDescription.replace("%data%", work.jobs[k].description);

            var formattedEmployerWorkTitle = formattedEmployer + formattedWorkTitle;

            $(".work-entry:last").append(formattedEmployerWorkTitle);
            $(".work-entry:last").append(formattedWorkLocation);
            $(".work-entry:last").append(formattedDates);
            $(".work-entry:last").append(formattedWorkDescription);
        }

    }

};

work.display();


projects.display = function() {
    if (projects.projects.length > 0) {
        $("#projects").append(HTMLprojectStart);

        for (var i = 0; i < projects.projects.length; i++) {
            var formattedProjectTitle = HTMLprojectTitle.replace("%data%", projects.projects[i].title).replace("#", projects.projects[i].url);
            var formattedProjectDates = HTMLprojectDates.replace("%data%", projects.projects[i].dates);
            var formattedProjectDescription = HTMLprojectDescription.replace("%data%", projects.projects[i].description);

            $(".project-entry:last").append(formattedProjectTitle);
            $(".project-entry:last").append(formattedProjectDates);
            $(".project-entry:last").append(formattedProjectDescription);

            for (var j = 0; j < projects.projects[i].images.length; j++) {
                var formattedProjectImage = HTMLprojectImage.replace("%data%", projects.projects[i].images[j]);
                $(".project-entry:last").append(formattedProjectImage);
            }


        }
    }
};

projects.display();

education.display = function() {
    if (education.schools.length > 0 || education.onlineCourses.length > 0) {
        for (var x = 0; x < education.schools.length; x++) {
            $("#education").append(HTMLschoolStart);

            var formattedSchoolName = HTMLschoolName.replace("%data%", education.schools[x]).replace("#", education.schools[x].url);
            var formattedSchoolDegree = HTMLschoolDegree.replace("%data%", education.schools[x].major);
            var formattedSchoolDates = HTMLschoolDates.replace("%data%", education.schools[x].dates);
            var formattedSchoolLocation = HTMLschoolLocation.replace("%data%", education.schools[x].location);
            var formattedSchoolMajor = HTMLschoolMajor.replace("%data%", education.schools[x].major);

            $(".education-entry:last").append(formattedSchoolName + formattedSchoolDegree);
            $(".education-entry:last").append(formattedSchoolDates);
            $(".education-entry:last").append(formattedSchoolLocation);
            $(".education-entry:last").append(formattedSchoolMajor);
        }

        if (education.onlineCourses.length > 0) {
            $("#education").append(HTMLonlineClasses);
            for (var s = 0; s < education.onlineCourses.length; s++) {
                $("#education").append(HTMLschoolStart);
                var formattedOnlineTitle = HTMLonlineTitle.replace("%data%", education.onlineCourses[s].title).replace("#", education.onlineCourses[s].url);
                var formattedOnlineSchool = HTMLonlineSchool.replace("%data%", education.onlineCourses[s].name);
                var formattedOnlineDates = HTMLonlineDates.replace("%data%", education.onlineCourses[s].dates);
                var formattedOnlineURL = HTMLonlineURL.replace("%data%", education.onlineCourses[s].url).replace("#", education.onlineCourses[s].url);

                $(".education-entry:last").append(formattedOnlineTitle + formattedOnlineSchool);
                $(".education-entry:last").append(formattedOnlineDates);
                $(".education-entry:last").append(formattedOnlineURL);
            }
        }

    }
};

education.display();

function inName(name) {
    var newName = name.split(" ");
    newName[1] = newName[1].toUpperCase();
    newName[0] = newName[0].slice(0, 1).toUpperCase() + newName[0].slice(1).toLowerCase();
    name = newName.join();
    return name;
}
$("#main").append(internationalizeButton);

$("#mapDiv").append(googleMap);